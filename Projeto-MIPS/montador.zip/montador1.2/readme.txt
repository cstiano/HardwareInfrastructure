usage:

I)
	Assembler.exe
	Default input file: instrucoes.txt
	Default output file: instrucoes.mif
	Default log file: log.txt

II)
	Assembler.exe [input file]
	Default output file: instrucoes.mif
	Default log file: log.txt

III)
	Assembler.exe [input file] [output file]
	Default log file: log.txt

IV)
	Assembler.exe [input file] [output file] [log file]